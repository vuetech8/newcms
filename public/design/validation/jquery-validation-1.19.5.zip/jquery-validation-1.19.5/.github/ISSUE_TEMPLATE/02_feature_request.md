---
name: Feature request
about: Wouldn't it be nice if jquery-validate could ...
labels: Feature

---

## New feature motivation

<!-- Describe the context, the use-case and the advantages of the feature request. -->

## New feature description

<!-- Optionally describe the functional changes that would have to be made. -->

## New feature implementation

<!-- Optionally describe the technical changes to be made in. -->
